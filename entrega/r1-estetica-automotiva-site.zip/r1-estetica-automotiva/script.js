(() => {
  const WA_NUMBER = "5521971232300";
  const WA_DEFAULT_MSG = "Olá! Encontrei a R1 Centro de Estética Automotiva pelo site e gostaria de solicitar um orçamento.";
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Links do WhatsApp com mensagem automática ---------- */
  document.querySelectorAll("[data-wa]").forEach((a) => {
    const msg = a.dataset.waMsg || WA_DEFAULT_MSG;
    a.href = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
  });

  /* ---------- Ano no rodapé ---------- */
  const year = document.querySelector("[data-year]");
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- Nav ---------- */
  const nav = document.getElementById("nav");
  const onScroll = () => nav.classList.toggle("is-scrolled", window.scrollY > 20);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  const toggle = nav.querySelector(".nav__toggle");
  const mobile = document.getElementById("menu-mobile");
  const setMenu = (open) => {
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
    mobile.hidden = !open;
    nav.classList.toggle("is-scrolled", open || window.scrollY > 20);
  };
  toggle.addEventListener("click", () => setMenu(mobile.hidden));
  mobile.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setMenu(false)));

  /* ---------- Aberto agora (horário de Brasília) ---------- */
  // [abre, fecha] em minutos; null = fechado
  const HOURS = { 0: null, 1: [480, 1020], 2: [480, 1020], 3: [480, 1020], 4: [480, 1020], 5: [480, 1020], 6: [480, 840] };
  const DAY_NAMES = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];
  const hh = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}h`;
  const nowInRio = () => {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Sao_Paulo", weekday: "short", hour: "numeric", minute: "numeric", hour12: false,
    }).formatToParts(new Date());
    const get = (t) => parts.find((p) => p.type === t).value;
    const day = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(get("weekday"));
    return { day, minutes: (parseInt(get("hour"), 10) % 24) * 60 + parseInt(get("minute"), 10) };
  };
  const updateStatus = () => {
    let day, minutes;
    try { ({ day, minutes } = nowInRio()); } catch { return; }
    const today = HOURS[day];
    const open = !!today && minutes >= today[0] && minutes < today[1];
    let text;
    if (open) {
      text = `Aberto agora · até ${hh(today[1])}`;
    } else if (today && minutes < today[0]) {
      text = `Fechado · abre hoje às ${hh(today[0])}`;
    } else {
      let d = 1;
      while (!HOURS[(day + d) % 7]) d++;
      const nd = (day + d) % 7;
      text = `Fechado · abre ${d === 1 ? "amanhã" : DAY_NAMES[nd]} às ${hh(HOURS[nd][0])}`;
    }
    document.querySelectorAll("[data-status]").forEach((el) => {
      el.classList.toggle("is-open", open);
      el.classList.toggle("is-closed", !open);
      el.querySelector("[data-status-text]").textContent = text;
    });
    document.querySelectorAll(".hours tr").forEach((tr) => {
      tr.classList.toggle("is-today", tr.dataset.days.split(",").map(Number).includes(day));
    });
  };
  updateStatus();
  setInterval(updateStatus, 60 * 1000);

  /* ---------- Galeria (fotos reais publicadas pela R1) ---------- */
  const IMG = "assets/img/";
  const WORKS = [
    { f: "corolla-polimento", t: "Toyota Corolla", s: "Polimento", c: ["polimento"], size: "xl" },
    { f: "ppf-instalacao", t: "PPF", s: "Instalação de película de proteção", c: ["protecao"], size: "tall" },
    { f: "kicks-pelicula", t: "Nissan Kicks", s: "Insulfilm / película", c: ["pelicula", "protecao"], size: "tall" },
    { f: "bmw-x1-vitrificacao", t: "BMW X1", s: "Vitrificação de pintura", c: ["protecao"], size: "tall" },
    { f: "fachada-equipe", t: "Equipe R1", s: "Polimento na loja", c: ["polimento", "loja"], size: "xl" },
    { f: "pelicula-vidro-traseiro", t: "Película", s: "Vidro traseiro", c: ["pelicula"], size: "tall" },
    { f: "fachada-r1", t: "A loja", s: "Estrada do Cabuçu, 471 · Campo Grande", c: ["loja"], size: "full" },
  ];

  const gallery = document.getElementById("gallery");
  gallery.innerHTML = WORKS.map((w, i) => `
    <button class="g-item${w.size ? " g-item--" + w.size : ""} reveal" data-i="${i}" data-cat="${w.c.join(" ")}" aria-label="Ampliar foto: ${w.t} — ${w.s}">
      <img src="${IMG}${w.f}${w.size === "xl" || w.size === "full" ? "" : "-sm"}.jpg" alt="${w.t} — ${w.s}" loading="lazy">
      <span class="g-item__zoom" aria-hidden="true">＋</span>
      <span class="g-item__meta"><strong>${w.t}</strong><span>${w.s}</span></span>
    </button>`).join("");

  const items = [...gallery.querySelectorAll(".g-item")];
  document.querySelectorAll(".filter").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter").forEach((b) => {
        b.classList.toggle("is-active", b === btn);
        b.setAttribute("aria-selected", String(b === btn));
      });
      const f = btn.dataset.filter;
      items.forEach((it) => {
        const show = f === "all" || it.dataset.cat.split(" ").includes(f);
        it.classList.toggle("is-hidden", !show);
        if (show) it.classList.add("is-in");
      });
    });
  });

  /* ---------- Lightbox ---------- */
  const lb = document.getElementById("lightbox");
  const lbImg = lb.querySelector("img");
  const lbCap = lb.querySelector(".lightbox__caption");
  const lbCount = lb.querySelector(".lightbox__count");
  let visible = [];
  let cur = 0;
  let lastFocus = null;

  const show = (idx) => {
    cur = (idx + visible.length) % visible.length;
    const w = WORKS[visible[cur]];
    lbImg.style.opacity = 0;
    const src = IMG + w.f + ".jpg";
    const img = new Image();
    img.onload = () => { lbImg.src = src; lbImg.alt = `${w.t} — ${w.s}`; lbImg.style.opacity = 1; };
    img.src = src;
    lbCap.textContent = `${w.t} — ${w.s}`;
    lbCount.textContent = `${String(cur + 1).padStart(2, "0")} / ${String(visible.length).padStart(2, "0")}`;
  };
  const open = (i) => {
    visible = items.filter((it) => !it.classList.contains("is-hidden")).map((it) => +it.dataset.i);
    lastFocus = document.activeElement;
    lb.hidden = false;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => lb.classList.add("is-open"));
    show(visible.indexOf(i));
    lb.querySelector(".lightbox__close").focus();
  };
  const close = () => {
    lb.classList.remove("is-open");
    document.body.style.overflow = "";
    setTimeout(() => { lb.hidden = true; }, reduceMotion ? 0 : 300);
    if (lastFocus) lastFocus.focus();
  };
  items.forEach((it) => it.addEventListener("click", () => open(+it.dataset.i)));
  lb.querySelector(".lightbox__close").addEventListener("click", close);
  lb.querySelector(".lightbox__prev").addEventListener("click", () => show(cur - 1));
  lb.querySelector(".lightbox__next").addEventListener("click", () => show(cur + 1));
  lb.addEventListener("click", (e) => { if (e.target === lb || e.target.tagName === "FIGURE") close(); });
  document.addEventListener("keydown", (e) => {
    if (lb.hidden) return;
    if (e.key === "Escape") close();
    if (e.key === "ArrowLeft") show(cur - 1);
    if (e.key === "ArrowRight") show(cur + 1);
  });
  let tx = null;
  lb.addEventListener("touchstart", (e) => { tx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener("touchend", (e) => {
    if (tx === null) return;
    const dx = e.changedTouches[0].clientX - tx;
    if (Math.abs(dx) > 50) show(cur + (dx < 0 ? 1 : -1));
    tx = null;
  });

  /* ---------- Resultados R1 (vitrine de fotos reais) ---------- */
  const showcase = document.getElementById("showcase");
  if (showcase) {
    const sImg = showcase.querySelector(".showcase__img");
    const sTag = showcase.querySelector("[data-showcase-tag]");
    const sRef = showcase.querySelector("[data-showcase-ref]");
    const tabs = [...document.querySelectorAll(".compare-tab")];
    tabs.forEach((tab, n) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => {
          t.classList.toggle("is-active", t === tab);
          t.setAttribute("aria-selected", String(t === tab));
        });
        showcase.classList.add("is-switching");
        const img = new Image();
        img.onload = () => {
          sImg.src = tab.dataset.src;
          sImg.alt = tab.dataset.alt;
          sTag.textContent = tab.dataset.tag;
          sRef.textContent = `REF · ${String(n + 1).padStart(2, "0")} / ${String(tabs.length).padStart(2, "0")}`;
          showcase.classList.remove("is-switching");
        };
        img.src = tab.dataset.src;
      });
    });
  }

  /* ---------- Intro: BMW com faróis acendendo e apagando ---------- */
  const carIntro = document.getElementById("intro-lamp");
  if (carIntro && document.documentElement.classList.contains("intro-on")) {
    const imgs = [...carIntro.querySelectorAll("img")];
    const ready = () => carIntro.classList.add("is-ready");
    Promise.all(imgs.map((im) => (im.complete ? Promise.resolve() : new Promise((r) => { im.onload = im.onerror = r; })))).then(ready);
    // padrão: apagado, acende, apaga rápido, acende de novo, apaga… (repete)
    const PATTERN = [[0.5, 0], [0.55, 1], [0.16, 0], [0.95, 1], [0.4, 0]];
    const TOTAL = PATTERN.reduce((t, p) => t + p[0], 0);
    const target = (t) => { let k = t % TOTAL; for (const [d, on] of PATTERN) { if (k < d) return on; k -= d; } return 0; };
    let level = 0, t0 = null, prev = performance.now(), mx = 0, my = 0;
    window.addEventListener("pointermove", (e) => { mx = e.clientX / window.innerWidth - 0.5; my = e.clientY / window.innerHeight - 0.5; }, { passive: true });
    const loop = (now) => {
      if (!document.body.contains(carIntro)) return;
      const dt = Math.min((now - prev) / 1000, 0.05); prev = now;
      if (carIntro.classList.contains("is-ready")) {
        if (t0 === null) t0 = now;
        const on = target((now - t0) / 1000);
        // LED liga rápido e apaga com leve decaimento
        level += (on - level) * (on > level ? 1 - Math.exp(-dt * 40) : 1 - Math.exp(-dt * 20));
        carIntro.style.setProperty("--lamp", level.toFixed(3));
        carIntro.style.setProperty("--px", `${(-mx * 14).toFixed(1)}px`);
        carIntro.style.setProperty("--py", `${(-my * 8).toFixed(1)}px`);
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  /* ---------- Intro ---------- */
  const root = document.documentElement;
  const intro = document.getElementById("intro");
  let introDone;
  const introFinished = new Promise((r) => { introDone = r; });
  if (root.classList.contains("intro-on") && intro) {
    intro.querySelectorAll(".intro__word span").forEach((el, i) => el.style.setProperty("--d", `${i * 0.025}s`));
    const pct = intro.querySelector("[data-intro-pct]");
    const bar = intro.querySelector(".intro__bar i");
    const log = intro.querySelector("[data-intro-log]");
    const LOGS = ["INICIANDO SISTEMA", "ANALISANDO PINTURA", "CALIBRANDO BRILHO", "APLICANDO PROTEÇÃO", "PRONTO"];
    const DURATION = 4400;
    const t0 = performance.now();
    let ended = false;
    const finish = () => {
      if (ended) return;
      ended = true;
      try { sessionStorage.setItem("r1-intro", "1"); } catch (e) {}
      intro.classList.add("is-leaving");
      setTimeout(introDone, 250);
      setTimeout(() => { root.classList.remove("intro-on"); intro.remove(); }, 1000);
    };
    // Espera o carro 3D carregar (até ~7s) e garante ~3s de faróis piscando depois disso
    const lampEl = document.getElementById("intro-lamp");
    let readyAt = null;
    let lastK = 0;
    const tick = (now) => {
      if (ended) return;
      if (lampEl && readyAt === null && (lampEl.classList.contains("is-ready") || !document.body.contains(lampEl) || now - t0 > 7000)) readyAt = now;
      const end = lampEl ? (readyAt === null ? Infinity : Math.max(t0 + DURATION, readyAt + 4600)) : t0 + DURATION;
      let k = end === Infinity ? Math.min((now - t0) / DURATION, 0.85) : Math.min((now - t0) / (end - t0), 1);
      k = lastK = Math.max(k, lastK);
      const eased = 1 - Math.pow(1 - k, 3);
      pct.textContent = String(Math.round(eased * 100)).padStart(3, "0");
      bar.style.setProperty("--p", eased);
      log.textContent = LOGS[Math.min(Math.floor(k * LOGS.length), LOGS.length - 1)];
      if (k < 1) requestAnimationFrame(tick);
      else setTimeout(finish, 280);
    };
    requestAnimationFrame(tick);
    intro.querySelector(".intro__skip").addEventListener("click", finish);
    intro.addEventListener("click", (e) => { if (e.target === intro) finish(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") finish(); });
    setTimeout(finish, 12000); // segurança
  } else {
    if (intro) intro.remove();
    introDone();
  }

  /* ---------- Animações de entrada ---------- */
  const reveals = document.querySelectorAll(".reveal");
  introFinished.then(() => {
  if (reduceMotion || !("IntersectionObserver" in window)) {
    reveals.forEach((el) => el.classList.add("is-in"));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const siblings = [...en.target.parentElement.children].filter((c) => c.classList.contains("reveal"));
        en.target.style.animationDelay = `${Math.min(siblings.indexOf(en.target), 6) * 70}ms`;
        en.target.classList.add("is-in");
        io.unobserve(en.target);
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    reveals.forEach((el) => io.observe(el));
  }

  });

  /* ---------- Parallax discreto no hero ---------- */
  const visual = document.querySelector(".hero__visual .hud-frame");
  if (visual && !reduceMotion && window.matchMedia("(pointer: fine)").matches) {
    const hero = document.querySelector(".hero");
    hero.addEventListener("mousemove", (e) => {
      const r = hero.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      visual.style.transform = `perspective(1200px) rotateY(${x * 4}deg) rotateX(${-y * 4}deg)`;
    });
    hero.addEventListener("mouseleave", () => { visual.style.transform = ""; });
    visual.style.transition = "transform .6s cubic-bezier(.2,.7,.1,1)";
  }

  /* ---------- Parallax da foto de fundo do hero ---------- */
  const heroBg = document.querySelector(".hero__bg img");
  if (heroBg && !reduceMotion) {
    let ticking = false;
    const moveBg = () => {
      ticking = false;
      const y = window.scrollY;
      if (y < window.innerHeight * 1.2) heroBg.style.setProperty("--py", `${-y * 0.18}px`);
    };
    window.addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(moveBg); } }, { passive: true });
  }

  /* ---------- Mapa interativo (tiles locais em assets/map) ---------- */
  const mapEl = document.getElementById("map");
  const initMap = () => {
    if (!mapEl || !window.L || mapEl.dataset.ready) return;
    mapEl.dataset.ready = "1";
    const POS = [-22.9073778, -43.5528746];
    const map = L.map(mapEl, {
      center: POS, zoom: 16, minZoom: 13, maxZoom: 18,
      maxBounds: L.latLngBounds([POS[0] - 0.04, POS[1] - 0.04], [POS[0] + 0.04, POS[1] + 0.04]),
      scrollWheelZoom: false, attributionControl: true, zoomControl: true,
    });
    const bounds = { 13: 0.045, 14: 0.03, 15: 0.018, 16: 0.011, 17: 0.0065, 18: 0.0045 };
    const layer = L.tileLayer("assets/map/{z}/{x}/{y}.png", {
      tileSize: 256, minZoom: 13, maxZoom: 18, maxNativeZoom: 18,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
      errorTileUrl: "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
    });
    layer.addTo(map);
    // limita o arrasto à área com tiles no zoom atual
    const clamp = () => {
      const d = bounds[map.getZoom()] || 0.0045;
      map.setMaxBounds(L.latLngBounds([POS[0] - d, POS[1] - d], [POS[0] + d, POS[1] + d]));
    };
    map.on("zoomend", clamp);
    clamp();
    const icon = L.divIcon({
      className: "",
      html: '<div class="map-pin"><span class="map-pin__pulse"></span><span class="map-pin__pulse map-pin__pulse--2"></span><span class="map-pin__dot"></span></div>',
      iconSize: [22, 22], iconAnchor: [11, 11], popupAnchor: [0, -14],
    });
    L.marker(POS, { icon, keyboard: true, title: "R1 Centro de Estética Automotiva" }).addTo(map)
      .bindPopup('<strong>R1 Estética Automotiva</strong>Estrada do Cabuçu, 471, Loja C<br>Campo Grande — Rio de Janeiro/RJ<br><a href="https://www.google.com/maps/dir/?api=1&destination=-22.9073778,-43.5528746&destination_place_id=ChIJv-fsUDrhmwARVOgA3B7kG3Y" target="_blank" rel="noopener">Traçar rota →</a>')
      .openPopup();
    // habilita zoom pela roda do mouse só após clicar no mapa
    map.on("click", () => map.scrollWheelZoom.enable());
    mapEl.addEventListener("mouseleave", () => map.scrollWheelZoom.disable());
  };
  if (mapEl) {
    if ("IntersectionObserver" in window) {
      const mo = new IntersectionObserver((en) => {
        if (en.some((e) => e.isIntersecting)) { initMap(); mo.disconnect(); }
      }, { rootMargin: "300px" });
      mo.observe(mapEl);
    } else {
      window.addEventListener("load", initMap);
    }
  }

  /* ---------- Carrosséis em rotação contínua (Instagram e avaliações) ---------- */
  document.querySelectorAll("[data-loop]").forEach((loop) => {
    const track = loop.querySelector(".loop__track");
    const originals = [...track.children];
    const speed = parseFloat(loop.dataset.speed) || 30; // px por segundo
    let setWidth = 0;
    let x = 0;
    let velocity = 0;       // inércia após soltar
    let dragging = false;
    let hovering = false;
    let visible = true;
    let lastX = 0, lastT = 0, startX = 0, moved = 0;

    const measure = () => {
      track.querySelectorAll("[data-clone]").forEach((c) => c.remove());
      const gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      setWidth = originals.reduce((w, el) => w + el.getBoundingClientRect().width + gap, 0);
      const copies = Math.max(1, Math.ceil(loop.clientWidth / setWidth) + 1);
      for (let n = 0; n < copies; n++) {
        originals.forEach((el) => {
          const c = el.cloneNode(true);
          c.setAttribute("data-clone", "");
          c.setAttribute("aria-hidden", "true");
          c.querySelectorAll("a, button").forEach((a) => a.setAttribute("tabindex", "-1"));
          if (c.matches("a")) c.setAttribute("tabindex", "-1");
          track.appendChild(c);
        });
      }
    };
    const wrap = () => {
      if (!setWidth) return;
      x = ((x % setWidth) + setWidth) % setWidth; // mantém 0 <= x < setWidth
      track.style.transform = `translate3d(${-x}px, 0, 0)`;
    };

    let prev = performance.now();
    const frame = (now) => {
      const dt = Math.min((now - prev) / 1000, 0.05);
      prev = now;
      if (visible && !dragging) {
        if (Math.abs(velocity) > 5) {
          x += velocity * dt;
          velocity *= Math.pow(0.04, dt); // desacelera suavemente
        } else if (!hovering && !reduceMotion) {
          velocity = 0;
          x += speed * dt;
        }
        wrap();
      }
      requestAnimationFrame(frame);
    };

    loop.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      dragging = true;
      moved = 0;
      velocity = 0;
      startX = lastX = e.clientX;
      lastT = performance.now();
    });
    window.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const now = performance.now();
      moved = Math.max(moved, Math.abs(e.clientX - startX));
      if (moved > 6 && !loop.classList.contains("is-dragging")) {
        loop.classList.add("is-dragging");
        try { loop.setPointerCapture(e.pointerId); } catch (err) {}
      }
      x -= dx;
      velocity = -dx / Math.max((now - lastT) / 1000, 0.001);
      lastX = e.clientX;
      lastT = now;
      wrap();
    });
    const release = () => {
      if (!dragging) return;
      dragging = false;
      if (performance.now() - lastT > 80) velocity = 0;
      velocity = Math.max(-2500, Math.min(2500, velocity));
      setTimeout(() => loop.classList.remove("is-dragging"), 0);
    };
    window.addEventListener("pointerup", release);
    window.addEventListener("pointercancel", release);
    // não abrir link se foi um arraste
    loop.addEventListener("click", (e) => { if (moved > 6) { e.preventDefault(); e.stopPropagation(); } }, true);

    if (window.matchMedia("(hover: hover)").matches) {
      loop.addEventListener("mouseenter", () => { hovering = true; });
      loop.addEventListener("mouseleave", () => { hovering = false; });
    }
    // teclado: setas movem o carrossel quando ele tem foco
    loop.tabIndex = 0;
    loop.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") { velocity = 900; e.preventDefault(); }
      if (e.key === "ArrowLeft") { velocity = -900; e.preventDefault(); }
    });
    if ("IntersectionObserver" in window) {
      new IntersectionObserver((en) => { visible = en[0].isIntersecting; }, { rootMargin: "100px" }).observe(loop);
    }

    measure();
    wrap();
    let rt;
    window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => { measure(); wrap(); }, 150); });
    window.addEventListener("load", () => { measure(); wrap(); });
    requestAnimationFrame(frame);
  });

  /* ---------- Botão de rotas: Google Maps / Waze / Uber ---------- */
  const route = document.querySelector("[data-route]");
  if (route) {
    const btn = route.querySelector(".fab__btn--map");
    const opts = [...route.querySelectorAll(".fab__opt")];
    const setOpen = (open) => {
      route.classList.toggle("is-open", open);
      btn.setAttribute("aria-expanded", String(open));
      btn.setAttribute("aria-label", open ? "Fechar opções de rota" : "Como chegar: escolher aplicativo");
      opts.forEach((o) => o.setAttribute("tabindex", open ? "0" : "-1"));
    };
    setOpen(false);
    btn.addEventListener("click", (e) => { e.stopPropagation(); setOpen(!route.classList.contains("is-open")); });
    opts.forEach((o) => o.addEventListener("click", () => setOpen(false)));
    document.addEventListener("click", (e) => { if (!route.contains(e.target)) setOpen(false); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && route.classList.contains("is-open")) { setOpen(false); btn.focus(); }
    });
  }
})();
